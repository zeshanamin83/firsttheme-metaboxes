<?php 
/**
 * First Theme Metaboxes
 *
 * @package     PluginPackage
 * @author      Your Name
 * @copyright   2019 Your Name or Company Name
 * @license     GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name: First Theme Metaboxes
 * Plugin URI:  
 * Description: This is my first plugin.
 * Version:     1.0.0
 * Author:      Zeshan Amin
 * Author URI:  https://facebook.com/zeshan.amin.5
 * Text Domain: firstthememetaboxes
 * License:     GPL v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */