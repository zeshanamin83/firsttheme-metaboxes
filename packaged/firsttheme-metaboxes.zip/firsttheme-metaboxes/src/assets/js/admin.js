alert('this is plugin js');
alert('new');